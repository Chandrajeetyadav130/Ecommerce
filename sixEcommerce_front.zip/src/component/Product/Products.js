import { useSelector,useDispatch } from "react-redux"
import React, { useState } from "react"
import { getProductAction } from "../../actions/productAction"
import { useEffect } from "react"
import Loader from "../layout/Loader/Loader"
import ProductCard from "../Home/ProductCard"
import "./Products.css"
import { useParams } from "react-router-dom"
import Pagination from "react-js-pagination";
// import Slider from "@material-ui/core/Slide"
import { Slider } from '@mui/material';
import Typography from "@material-ui/core/Typography"

const Products=()=>{

    const {keyword}=useParams()
    const [currentPage,setCurrentPage]=useState(1)
    const [price,setPrice]=useState([0,3000000])
    const {product,loading,error,productCount,resultPerpage} =useSelector(state=>state.product)
    const dispatch=useDispatch()
    const setCurrentPageNo=(e)=>{
        setCurrentPage(e)
    }

     useEffect(()=>{
        dispatch(getProductAction(keyword,currentPage,price))
     },[dispatch,keyword,currentPage,price])
     const priceHandler=(event,newPrice)=>{
        // console.log(newPrice)
        setPrice(newPrice)
    }
    return(
        <React.Fragment>
            {loading?(<Loader/>):(
                <React.Fragment>
                    <h2 className="products_heading">Products</h2>
                    <div className="products my-4">
                       {product&&
                       product.map((product)=><ProductCard key={product._id} products={product}/>)}
                    </div>
                    <div className="filter_container">
                        <Typography>Price</Typography>
                        <Slider
                        value={price}
                        onChange={priceHandler}
                        valueLabelDisplay="auto"
                        aria-labelledby="range-slider"
                        min={0}
                        size="small"
                        max={3000000}
                        />

                    </div>
                    {
                        <div className="paginationPage">
                        <Pagination 
                        activePage={currentPage}
                        itemsCountPerPage={resultPerpage}
                        totalItemsCount={productCount}
                        onChange={setCurrentPageNo}
                        nextPageText="Next"
                        prevPageText="Prev"
                        firstPageText="1st"
                        lastPageText="Last"
                        itemClass="page-item"
                        linkClass="page-link"
                        activeClass="pageItemActive"
                        activeLinkClass="pageLinkActive"
                        />
                    </div>
                    }
                    
                </React.Fragment>
            )}
        </React.Fragment>
    )
}
export default Products